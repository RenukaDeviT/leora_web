import * as videoGroupCallWeb from "./videoGroupCallWeb";

export default {
  videoGroupCallWeb,
};
