export { default } from './DeviceSettings';
