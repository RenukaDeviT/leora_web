export const SUPPORT_URL = "https://www.leora.ai/contact";
export const routePaths = {
  home: "/join_session",
  videoCall: "/VideoCallTrigger",
  endSession: "/end_session",
};
export const decryption = {
  key: "8C56F5AD03984EA0A307C0D36BD3326ED4E61605DB9C43DB90522C44B1C9AE6F",
  iv: "1234567890987654",
};
